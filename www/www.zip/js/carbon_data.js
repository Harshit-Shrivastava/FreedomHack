var carbonData = {
	'freight': {
		'road':  160
	}, 
	'passenger': {
		'car': 175,
		'train': 75,
		'flight': 229
	} 
}